#include<iostream>

/*static functions of the class */

using namespace std;

class Data{
	
	public:
	static void go();	
};

void Data::go(){
	
	cout<<"The Go Functions of the class"<<endl;
}

/*
	static  functions are called without the object of the class
*/

int main()
{
	Data::go();
}

