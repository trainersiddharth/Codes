
#include<iostream>

using namespace std;

class Data{
	
	public:
		
	Data();
	~Data();
	
	void display(){
		cout<<"The Display function"<<endl;
	}
};

Data::Data(){
	cout<<"Constructor"<<endl;
}

Data::~Data(){
	cout<<"Desctructor"<<endl;
}


int main(){
	
	Data i;
	i.display();	
	cout<<"End"<<endl;
}

