

/* call by reference of the variables*/

#include<iostream>
using namespace std;


//cal by reference -> pointer help 
void swap1(int *a , int *b);
//cal by reference -> alias
void swap2(int &a , int &b);


//cal by value -> no interchange done
void swap3(int a , int b);


void swap1(int *a , int *b){
	
	// this is swaping
	int temp=*a;
	*a=*b;
	*b=temp;
}

void swap2(int &a , int &b){
	// this is swaping
	int temp=a;
	a=b;
	b=temp;
}

void swap3(int a,int b){
	
	int temp=a;
	a=b;
	b=temp;	
}

int main(){
	
	int n1=12 , n2=34;
	
	/*cal by reference through pointer */
	swap1(&n1, &n2);
	
	cout<<"N1:"<<n1<<endl;
	cout<<"N2:"<<n2<<endl;
	
	cout<<"________________________________"<<endl;
	
	
	/*cal by reference through alias */
	swap2(n1,n2);
	
	cout<<"N1:"<<n1<<endl;
	cout<<"N2:"<<n2<<endl;	
	
	cout<<"________________________________"<<endl;
	
	/*cal by value - no change in (n1 & n2) */
	
	swap3(n1, n2);
		
	cout<<"N1:"<<n1<<endl;
	cout<<"N2:"<<n2<<endl;	
	
}

