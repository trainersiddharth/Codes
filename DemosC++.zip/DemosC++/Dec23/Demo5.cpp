
#include<iostream>

using namespace std;


class Data{
	
	int n1 , n2;
	
	public:
		
	Data(int num1 , int num2){
		n1=num1;
		n2=num2;
	}
	
	~Data(){
		n1 =-1;
		n2=-1;		
	}
	
	void display(){
		cout<<"N1:"<<n1<<endl;
		cout<<"N2:"<<n2<<endl;
	}
};

int main()
{
	int x, y;
	cout<<"enter the numbers"<<endl;
	cin>>x>>y;
	
	Data i(x,y);
	i.display();
}
