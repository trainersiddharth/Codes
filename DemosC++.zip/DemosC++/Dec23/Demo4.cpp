#include<iostream>
using namespace std;

/*
desctructor:

1) same name as that of the class 
2) prefix by titled 
3) used to deallocate the memory of the variables

*/


class Sample{
	
	public:
	
	/*this is the constructor of the class*/
	Sample(){
		cout<<"This is the constructor of the class"<<endl;
	}	
	
	/* desctructor: prefix by titled in (c++) */
	
	~Sample(){
		cout<<"This is the desctructor of the class"<<endl;
	}	
};

int main()
{
	Sample obj;
	obj.~Sample();
}
