
#include<iostream>
// these are the macros in C++
#define NAME "John"
#define AGE 34

using namespace std;

int main(){
	
	cout<<NAME<<endl;
	cout<<AGE<<endl;
}
