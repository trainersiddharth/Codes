#include<iostream>

using namespace std;

int main()
{
	/*declare the array*/
     int num[3];
    	
    /* for ( 0 , 1 , 2) */	
    for(int i=0;i<3;i++)
	{
	 cout<<"Enter the Number"<<endl;
	 cin>>num[i];
	 }
	 
	cout<<"The values are:"<<endl;	
	 
	 /* Index: 0,1,2 */	
	for(int i=0;i<3;i++)
	{
	 
	 cout<<num[i]<<endl;
	}

}
