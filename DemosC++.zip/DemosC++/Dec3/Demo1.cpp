
#include<iostream>

using namespace std;

/*
	What is Array: Group of values of Similar Data type

	Types of Array:	
	
	Single Dimentional 
	
	Multi Dimentional ( Arrays of Arrray)
	
	Declare Single Dimensional Array
	
	<data-type> <array-name>[size];
	
	Starting index: 0
	last index : size-1
	
	eg:
	
	int num[4];
	
	num[0]
	num[1]
	num[2]
	num[3]
*/

int main()
{
	/*declare the array*/
     int num[3];
    	
    /* Index: 0 */	
	 cout<<"Enter the Number"<<endl;
	 cin>>num[0];
 	
	 /* Index:1 */		 
	 cout<<"Enter the Number"<<endl;
	 cin>>num[1];
 	
	 /* Index:2 */		 
	 cout<<"Enter the Number"<<endl;
	 cin>>num[2];
	 
	 cout<<"The values are:"<<endl;
	 
	 /* Index: 0 */	
	 cout<<num[0]<<endl;
	 /* Index: 1 */	
	 cout<<num[1]<<endl;
	 /* Index: 2 */	
	 cout<<num[2]<<endl;	 
}
