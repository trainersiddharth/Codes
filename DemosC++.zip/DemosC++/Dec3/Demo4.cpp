

#include<iostream>
#include<string.h>

using namespace std;

int main()
{
	
	char name[20]="James";
	
	int size=strlen(name);
	
	for(int i=0;i<size;i++)
	{
		/*printing character by character data*/
		cout<<name[i];
	}
	
	for(int i=0;i<20;i++)
	{
		/*printing complete name */
		cout<<name<<endl;
	}
}
