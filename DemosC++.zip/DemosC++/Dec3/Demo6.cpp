

#include<iostream>

using namespace std;

int main(){


	 int a[5], b[5];
	 
	 for(int i=0;i<5;i++){
	 	cout<<"Enter the Value in A"<<endl;
	 	cin>>a[i];
	 }
	 
	 for(int i=0;i<5;i++){
	 	cout<<"Enter the Value in b"<<endl;
	 	cin>>b[i];
	 }
	 
	cout <<"Sum	of the Array is"<<endl;
	
	 for(int i=0;i<5;i++){
	 	cout<<a[i]<<"\t"<<b[i]<<"\t"<<(a[i]+b[i])<<endl;
	 }
	 
}
