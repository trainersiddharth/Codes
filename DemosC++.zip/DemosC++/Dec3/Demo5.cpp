#include<iostream>

using namespace std;

int main()
{
	cout<<"Hello World in the class Demo"<<endl;
}
