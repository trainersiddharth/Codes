
#include<iostream>

using namespace std;

int main()
{
	/* directly providing values */
	
	int arr[3]={12,1,34};	
	
	cout<<"The values are:"<<endl;
	
	/* Loop for printing the values */
	
	for(int i=0;i<3;i++)
	{
		cout<<arr[i]<<endl;
	}
	
}
