
#include<iostream>

using namespace std;

int main(){
	
	int a[5],i ,e=0,o=0;
	for(int i=0;i<5;i++){
	cout<<"Enter the Number"<<endl;
	cin>>a[i];
		if(a[i]%2==0){
		e++;
		}else{
		o++;
		}
	}
	
	cout<<"Even Numbers: "<<e<<endl;
	cout<<"Odd Numbers: "<<o<<endl;
}
