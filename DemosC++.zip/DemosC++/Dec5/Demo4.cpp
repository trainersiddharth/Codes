
#include<iostream>

using namespace std;

int main()
{
	int num;
	
	cout<<"Enter the Number"<<endl;
	cin>>num;
	int sum=0;
	
	while(num>0){
		sum+=(num%10);
		num/=10;
	}
	
	cout<<"The Sum of Digit is"<<sum<<endl;
}
