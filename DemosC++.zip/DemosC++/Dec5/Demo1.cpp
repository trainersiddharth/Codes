#include<iostream>

using namespace std;

int main(){
	
	int a[5],max=0;
	
	
	for(int i=0;i<5;i++){
		
		cout<<"Enter the Number"<<endl;
		cin>>a[i];
		
		if(a[i]>max){
			max=a[i];
		}
	}
	
	cout<<"The maximum value is "<<max<<endl;
}

