#include<iostream>

using namespace std;

int main(){
	
	int a[5],sum=0;
	
	for(int i=0;i<5;i++){
	cout<<"Enter the Number"<<endl;
	cin>>a[i];
	sum+=a[i];
	}
	
	cout<<"The Sum of All the values of Array is "<<sum<<endl;
	
	
	
}
