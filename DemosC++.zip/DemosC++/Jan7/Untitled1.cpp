
#include<iostream>

 using namespace std; 


int main(){
	
	int arr[5]={34,546,22,45,22};
	
	for(int i=0;i<5;i++)
	{
		cout<<arr[i]<<endl;
	}
		
		
		
	for(int i=0;i<5;i++)
	{
		cout<<(arr+i)<<"-"<<*(arr+i)<<endl;
	}	
}
