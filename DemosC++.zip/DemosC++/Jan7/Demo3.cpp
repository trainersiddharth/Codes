#include<iostream>
#include<fstream>
#include<string.h>

using namespace std;

int main(){
	
	char content[40]="File must have these content";
	
	/*writing content of the file (character  by character)*/		
	
	ofstream dat("sample.txt");
	
	// size of the string
	int x=strlen(content);
	
	for(int i=0;i<x;i++){
		//used to send the content in the file
		dat.put(content[i]);
	}
	
	cout<<content<<endl;.
	
	dat.close();
	
}
