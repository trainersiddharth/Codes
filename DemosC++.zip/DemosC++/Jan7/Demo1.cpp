#include<iostream>
#include<fstream>

using namespace std;


int main(){
	
	/* predefined class for writing content in the file (line by line)*/
	ofstream dat("Data.txt");
	dat<<"The content will be in the file "<<endl;
	dat.close();
}
