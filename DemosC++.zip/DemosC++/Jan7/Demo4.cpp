#include<iostream>
#include<fstream>
using namespace std;

int main(){
	
	/* reading the content of the file character by character*/
	ifstream c("sample.txt");
	int x=c.get();
	//(-1) End of File 
	 
	while(x != -1){
		cout<<(char)x;
		x=c.get();
	}
}

