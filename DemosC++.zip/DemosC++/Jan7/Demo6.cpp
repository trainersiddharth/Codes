#include<iostream>
#include<fstream>

using namespace std;


int main(){
	
	/* appending the content of the file*/
	ofstream dat("Data.txt",ios::app);
	dat<<"The content will be in the file "<<endl;
	dat.close();
}
