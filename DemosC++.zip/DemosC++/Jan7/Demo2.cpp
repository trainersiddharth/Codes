#include<iostream>
#include<fstream>
using namespace std;

int main()
{

	char content[49];
	
	/*reading the content of the file (line by line)*/
	ifstream dat("Data.txt");
	dat.getline(content,48,'\n');
	
	cout<<content<<endl;
}

