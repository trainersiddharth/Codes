#include<iostream>

using namespace std;

class  a1{
	
	public:
	
	void d(){
		cout<<"a1"<<endl;
	}	
};

class  a2{
	
	public:
	
	void d(){
		cout<<"a1"<<endl;
	}	
	
};


class  Sample:public a1 , public a2{
	
};


class Data{
	
	public:
	static int a;
	void accept();
	void display();	
	
	static void go(){
		cout<<"Sample"<<endl;
	}
};

int Data::a=56;

void Data::accept(){
	cout<<"Accept function of the class"<<endl;
}

void Data::display(){
	cout<<"Display function of the class"<<endl;
}

int main(){
	
	Data *obj=new Data;
	
	obj->accept();
	obj->display();
	
	Data::go();
	
	cout<<Data::a<<endl;
	
	Sample obj1;
	obj1.a1::d();
}


