
/*
	recursion : function calling itself 
	
	recursion helps in avoiding loops 
*/


#include<iostream>

using namespace std;


void print(int times)
{
	if(times>10){
		cout<<"hello World"<<endl;
		/*this is recursion */
		print(--times);
	}
}


int main (){
	
	print(15);
}


/*
		DRY RUN 
		 
		times -> 5  true  "Hello World"
		times -> 4  true  "Hello World"
		times -> 3  true  "Hello World"
		times -> 2  true  "Hello World"
		times -> 1  true  "Hello World"
		
		times -> 0  false  
*/
