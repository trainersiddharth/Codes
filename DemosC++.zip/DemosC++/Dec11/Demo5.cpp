
#include<iostream>

// 5  !5 => 5*4*3*2*1  , 4*3*2*1 ,

using namespace std;

int factorial(int n){
	//return (n==0)?1:factorial(n-1)*n;
	
	if(n==0){
		return 1;
	}else{
		return factorial(n-1)*n;
	}
}

int max(int a, int b)
{
	return (a>b)?a:b;
}

int main()
{
	cout<<factorial(5)<<endl;
}
