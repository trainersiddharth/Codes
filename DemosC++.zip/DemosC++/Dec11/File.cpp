#include<iostream>
using namespace std;

void doWork(){
	cout<<"Work in the company"<<endl;
}

int sum(int a , int b){
	return a+b;
}

int mul(int a , int b){
	return a*b;
}


