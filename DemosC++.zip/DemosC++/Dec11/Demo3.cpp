#include<iostream>
#include"File.cpp"

using namespace std;

int main()
{
	doWork();
	
	cout<<mul(23,3)<<endl;
	cout<<sum(23,3)<<endl;
}
