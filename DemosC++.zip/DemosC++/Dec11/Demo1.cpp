#include<iostream>

/*
	functions in C++
	
	<return-type> <function-name>(<parameter>)
	{
	   body of the function
	}
	
	<return-type> :
	 
	 void or any of the <data-type>
	 
	 <function-name> :
	 
	 act as the identifier 
	 
	 <parameter> :
	 
	 used to send values inside function
	 
	 
	 
*/


using namespace std;

/* global function */

void display()
{
 cout<<"The Display function of the Program "<<endl;
}

int sum(int a, int b){
	int c =a+b;
	
	return c;
}

int main()
{
	display();
	
	/* 2 steps */
	
	int ans=sum(12,34);
	cout<<ans<<endl;
	
	/* single step */
	
	cout<<sum(12,34)<<endl;
}
