
#include<iostream>

using namespace std;

/* declare the functions */
void display();

/* body of the function */

void display()
{
	cout<<"Hello World"<<endl;
}

int main()
{
  display()	;
}
