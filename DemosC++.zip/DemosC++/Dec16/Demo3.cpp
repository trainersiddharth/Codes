#include<iostream>

using namespace std;

class Data
{
    public:
	
	void display()
	{
		cout<<"The Display function of the class is here"<<endl;
	}
};

int main()
{
	// this is the object of the class
	Data gunjan;
	// calling to the function of the class
	gunjan.display();
}




