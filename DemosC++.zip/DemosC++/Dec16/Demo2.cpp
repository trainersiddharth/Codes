#include<iostream>

using namespace std;

int main()
{
	int num,sum=0;
	
	for(int i=0;i<10;i++){
	cout<<"Enter the Number"<<endl;
	cin>>num;
	sum+=num;
	}
	
	cout<<"THe Sum of the Numbers are:"<<sum<<endl;
}
