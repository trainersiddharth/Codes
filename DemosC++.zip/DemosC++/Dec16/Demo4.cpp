#include<iostream>

using namespace std;

class A{
	
	public:
	
	void display(){
	cout<<"The Display function A"<<endl;
	}
	
};

class B{

	public:
	
	void display(){
	cout<<"The Display function B"<<endl;
	}	
};


class C{
	
	public:
	
	void display(){
	cout<<"The Function of class C"<<endl;	
	}	
};

int main()
{
	A obj ;
	B obj1;
	C obj2;
	
	obj.display();
	obj1.display();
	obj2.display();
}


