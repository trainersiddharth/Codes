#include<iostream>

using namespace std;

/*
	Sum  of first n natural numbers
	
	sum = [n* (n+1)] /2
*/

int main()
{
	int num;
	
	cout<<"Enter the Number"<<endl;
	cin>>num;
	
	int sum =num*(num+1)/2;
	cout<<"The Sum of Numbers are: "<<sum<<endl;
}
