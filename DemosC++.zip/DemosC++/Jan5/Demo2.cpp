
#include<iostream>

using namespace std;

class Sample{
	
	public:
	
	/* these are known as pure virtual functions */
	virtual void a()=0;	
};

class Child :public Sample{
	
	public:
	
	/* override  is compalsury */
		
	void a(){
		cout<<"The Go Function of the class"<<endl;
	}	
	
};

int main(){
	
	Child  obj;
	obj.a();
}
