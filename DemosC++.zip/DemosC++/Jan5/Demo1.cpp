#include<iostream>

using namespace std;


/*
	virtual base classes: 
*/



class Data{
	
	public:
		
	void display(){
	cout<<"Display function of the class"<<endl;	
	}
};

/* Child is the Child class of Data*/
class Child:public Data{
	
};


int main(){
	
	/*Child class object */	
	
	Child c ;
	c.display();
}
