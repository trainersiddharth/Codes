#include<iostream>

using namespace std;


class Data{
	
	public:
	
	void run(){
		cout<<"The run function of the class we used "<<endl;
	}	
};

int main(){
	
	// 'new' is keyword for creating the reference of the class
	Data *ptr =new Data;
	ptr->run();
}
