#include<iostream>

using namespace std;

int main(){
	
	int num =056;
	
	cout<<"The number is "<<num<<endl;
}
