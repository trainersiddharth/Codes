#include<iostream>

using namespace std;

int main(){
	
	int a, b;
	
	cout<<"enter the number"<<endl;
	cin>>a>>b;
	
	if(a>b){
		cout<<"A is greater"<<endl;
	}else{
		cout<<"B is Greater"<<endl;		
	}
	
	
}
