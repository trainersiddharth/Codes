
/* functions in c++

 	what is function?
 	
 	function is a code module which consist of more then one statement
 	
 	
 	Types of functions
 	
 	1) no return no arguments
 	2) no return has arguments
 	3) return no arguments
 	4) return has arguments
 	
 	
 	Syntax of Creating the Function
 	
 	<return-Type> <function-name>(<parameters>)
	 {
 	
	 	body of the function	
	 }
	 
	 <return-Type> : void or any of the <data-type>
	 
	 <function-name> : act as the identifier
	 
	 <parameters> : send information inside function
 	
*/

#include<iostream>

using namespace std;


/* global function : functions which are accessible */




// 	1) no return no arguments

void data(){
	
	cout<<"The Data function of the program is available "<<endl;
}

int main(){
	
	//calling the global function
	data();
}



