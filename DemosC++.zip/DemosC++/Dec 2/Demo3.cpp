
#include<iostream>

using namespace std;

int main(){
	
	cout<<"Hello world from the program by us"<<endl;
}
