#include<iostream>

using namespace std;

int main(){
	
	
	cout<<"Writing the first program in dev c++ "<<endl;
}
