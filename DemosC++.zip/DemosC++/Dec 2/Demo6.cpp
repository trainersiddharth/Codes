
#include<iostream>
#include "a.cpp"

using namespace std;

int main(){
	
	display();
	data(12,2);
	
	/*2 steps*/
	int ans=value();
	cout<<ans<<endl;
	
	/* 1 step */
	cout<<value()<<endl;
	
	int a=12 , b=34;
	
	int c =sum(a,b);
	cout<<c<<endl;
}
