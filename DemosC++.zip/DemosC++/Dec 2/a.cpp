
using namespace std;

// 1) no return no arguments

void display(){
	cout<<"The Display function of the class"<<endl;
}

// 2) no return has arguments

void data(int a, int b){
	cout<<"A is "<<a<<" & b is "<<b<<endl;
}

// 3)  return no arguments

int value(){
	return 133;
}

// 4)  return  arguments


int sum(int a, int b){
	return a+b;
}
