#include<iostream>

using namespace std;

int main()
{
	 char names[4][20];
	 
	 /* input from the user */
	 
	 for(int i=0;i<4;i++)
	 {
	 	cout<<"Enter the Name"<<endl;
	 	cin>>names[i];
	 }
	 
	 
	 /* display values back to the user*/
	 
	 cout<<"The Names are:"<<endl;
	 
	 for(int i=0;i<4;i++)
	 {
	 	cout<<names[i]<<endl;
	 }
}
