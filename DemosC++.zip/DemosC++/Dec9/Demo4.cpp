
#include<iostream>

using namespace std;
 

int main()
{
	char name[20];
	
	cout<<"Enter the Name"<<endl;
	/* data after space is in the string as well */
	cin.getline(name,19,'\n');
	
	cout<<"The Name is "<<name<<endl;
}
