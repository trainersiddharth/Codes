#include<iostream>

using namespace std;

int main()
{
	int arr[2][3];
	
	 
	  /*
	  	 	0,0   0,1   0,2
	  	 	1,0	  1,1	1,2 	
	  */
	
	
	/* input from user */
	
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<3;j++)
		{
			cout<<"Enter the Number"<<endl;
			cin>>arr[i][j];
		}
	}
	
	/* display values back to the user */
	
	cout<<"The values are: "<<endl;
	
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<3;j++)
		{
			cout<<arr[i][j]<<"\t";
		}
		
		cout<<"\n";
	}
}
