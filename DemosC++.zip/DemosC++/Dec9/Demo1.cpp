#include<iostream>

using namespace std;

int main()
{
	 /* 
	  Muti dimensional array (rows and columns ) 
	  
	  <data-type> <array-name>[size]; ( 0 -> Size-1)
	 
	  <data-type> <array-name>[rows][columns] ( 0,0 -> size-1 , size-1);
	 
	 */
	 
	  int arr[2][3]={{1,2,3},{4,5,6}};
	  
	  /*
	  	 	0,0   0,1   0,2
	  	 	1,0	  1,1	1,2 	
	  */
	  
	  
	  
	  //outer loop -> no of rows
	  for(int i=0;i<2;i++)
	  {
	  	//inner loop -> no of columns
	  	for(int j=0;j<3;j++)
	  	{
	  	  cout<<arr[i][j]<<"\t";			
		}
		
		cout<<"\n"; 
	  }
	  
}
