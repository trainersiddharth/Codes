#include<iostream>

/*
		to access private data outside class 
		(friend functions or friend classes)
		
		 'void Meta::doWork()' is private
*/

using namespace std;


class Meta{
	
	/*shows that main is the friend of (class Meta) */
	friend int main();
	
	private:
	
	void doWork(){
		cout<<"Do work in main() function"<<endl;
	}	
};

class Data{
	
	/*shows that main is the friend of (class Data) */
	friend int main();
	
	private:
		
	void display(){	
		cout<<"The Display function"<<endl;	
	}	
};


/* this function is  the friend of class */
int main(){
		
	Data obj;
	obj.display();	
	
	Meta x;
	x.doWork();
	
	
}


