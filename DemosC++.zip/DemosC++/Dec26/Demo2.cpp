#include<iostream>

using namespace std;

/*
	friend classes in C++
	
	Error:  'void Sample::doWork()' is private
*/

class Sample{
	
	/* making friend class (Data)*/
	
	friend class Data;
	
	private :
		
	void doWork(){
		cout<<"The Data function is here"<<endl;
	}	
};

class Data{
	
	public:
	
	void useMe(){
		cout<<"for calling() functions"<<endl;
		
		/*calling the private function of class Sample */
		Sample obj;
		obj.doWork();		
	}	
	
};

int main(){
		
	Data obj;
	obj.useMe();	
}

