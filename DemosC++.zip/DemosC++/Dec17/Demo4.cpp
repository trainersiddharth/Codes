#include<iostream>
using namespace std;

/* default mode is private in the class for variables and functions */

class Data{
	
	private:
	
	int num ,num1 ; 
	
	public:
	
	void accept(){
	/* value to the variables */
	
	cout<<"Enter the Number"<<endl;
	cin>>num;
	
	cout<<"Enter the Number"<<endl;
	cin>>num1;		
	}
	
	void sum(){
		cout<<"The Sum of the numbers are: "<<(num+num1)<<endl;
	}	
	void sub(){
		cout<<"The Sub of the numbers are: "<<(num-num1)<<endl;
	}		
	void mul(){
		cout<<"The Product of the numbers are: "<<(num*num1)<<endl;
	}	
	void div(){
		cout<<"The Division of the numbers are: "<<(num/num1)<<endl;
	}			
};	

int main()
{
	/* created the object of the class*/
	
	Data obj;

	/* call the functions of the class*/
	
	obj.accept();
	obj.sum();
	obj.mul();
	obj.div();	
	
}
