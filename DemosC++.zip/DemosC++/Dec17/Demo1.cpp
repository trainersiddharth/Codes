#include<iostream>

using namespace std;

class Data
{
	 public:
	 
	 void display(){
	 	cout<<"THe display function of the class is here"<<endl;
	 }	
	 
	 void print(){
	 	cout<<"The print() is here "<<endl;
	 }
	 
	 
	 void doWork(){
	 cout<<"The Do Work function of the class "<<endl;
	 }
	 
	 private:
	 	
	 void sample(){
	 	cout<<"The Sample is Here"<<endl;
	 }	
};

int main()
{
	/* create the object */
	Data obj;
	
	/* calling to the functions of class Data through object*/
	
	obj.display();
	//obj.sample();
	obj.print();
	obj.doWork();
}
