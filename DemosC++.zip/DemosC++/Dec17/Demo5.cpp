#include<iostream>

using namespace std;

class Hour{
	
	 private:
	 	
	 char name[20];
	 int age;
	 
	 public:
	 	
	 void accept();
	 void display();
};

/*
 When body to  the functions are provided outside class

 <return-type> <class-name>::<function-name>()
 {

 }

*/


void Hour::accept(){
	cout<<"Enter the name "<<endl;
	cin>>name;
	cout<<"Enter the Age"<<endl;
	cin>>age;
}

void Hour::display(){
	cout<<"The name is "<<name<<" &  the age is "<<age<<endl;
}


int main()
{
	//<class-name > <object-name>;
	
	Hour o;
	
	//<object-name>.<function-name / variable-name >
	o.accept();
	o.display();
	
	cout<<"_____________________________________"<<endl;
	
	/* POinter of the class*/ 
	
	Hour *p =new Hour;
	
	p->accept();
	p->display();
	
}



