#include<iostream>
using namespace std;

class Data{
	
	public:
	void display();
	void print();
	void doWork();
	
	private:
	void sample();	
};


void Data::display(){
	cout<<"Display function of the class is here"<<endl;
}


void Data::print(){
	cout<<"print()  is used from the class"<<endl;
}

void Data::doWork(){
	cout<<"The Do Work function of the class is here"<<endl;
	sample();
}

void Data::sample(){
	cout<<"The sample() function is there"<<endl;
}

int main()
{
	Data obj ;	
	obj.doWork();

}


