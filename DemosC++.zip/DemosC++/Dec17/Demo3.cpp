#include<iostream>
using namespace std;

class Data{
	
	public:
	int num ,num1 ; 
	
	void sum(){
		cout<<"The Sum of the numbers are: "<<(num+num1)<<endl;
	}	
	void sub(){
		cout<<"The Sub of the numbers are: "<<(num-num1)<<endl;
	}		
	void mul(){
		cout<<"The Product of the numbers are: "<<(num*num1)<<endl;
	}	
	void div(){
		cout<<"The Division of the numbers are: "<<(num/num1)<<endl;
	}			
};	

int main()
{
	/* created the object of the class*/
	
	Data obj;
	
	/* value to the variables */
	
	cout<<"Enter the Number"<<endl;
	cin>>obj.num;
	
	cout<<"Enter the Number"<<endl;
	cin>>obj.num1;
	
	/* call the functions of the class*/
	
	obj.sum();
	obj.mul();
	obj.div();
	
	
	
}
