#include<iostream>

using namespace std;

class Data{
	
	public:
	
	void go();	
};

void Data::go(){
	cout<<"The Go Function of the class is here"<<endl;
}


int main(){
	
	Data obj ;
	obj.go();
}
