#include<iostream>

using namespace std;

/*
	Constructor & Desctructor  in C++
	
	Constructor:
	
	1) Same name as that of the class
	2) no return type
	3) automatically invoke when we create the object of the class
	4) default constructor is without parameter
	5) used to initialize the member variable of the class
	6) we can have more than one constructor in the class but of different signature
	
	what is signature?
	Signature include 3 things
	
	1) no of parameter
	2) sequence of parameter
	3) type of parameter
	
*/

class Data{
	
	public:
		
	/* this is the default constructor of the class */	
	Data(){
		cout<<"I will invoke automatically when you create the object of the class"<<endl;
	}	
};


int main()
{
	/* object of the class*/
	 Data obj;
}
