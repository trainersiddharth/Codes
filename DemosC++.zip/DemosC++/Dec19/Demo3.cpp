#include<iostream>
using namespace std;

class Sample{
	
	public:
		
	Sample();	
};

/* this is the default constructor of the class*/

Sample::Sample(){
	cout<<"body to the constructor"<<endl;
}


int main(){
	
	Sample obj;
}
