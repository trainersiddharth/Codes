/*
	parameterized constructor in the class 
*/

#include<iostream>

using namespace std;

class Data{
	
	int num1 , num2 ;
	
	public:
	
	/*parameterized constructor  of the class */
	
	Data(int a, int b){
		
		/* variables of the class are initialized */
		
		num1=a;
		num2=b;
	}	
	
	void display(){
		/* display the values to the user*/
		
		cout<<"Num1: "<<num1<<endl;
		cout<<"Num2: "<<num2<<endl;
	}
	
	int sum(){
		return  num1+num2;
	}
	
	int mul(){
		return num1 *num2 ;
	}

	int div(){
		return num1/num2 ;
	}
	
	int sub(){
		return num1 -num2 ;
	}
	
};

int main(){
	
	Data obj(12,2);
	/* shows the value */
	obj.display();
	
	cout<<"Sum:"<<obj.sum()<<endl;
	cout<<"Div:"<<obj.div()<<endl;
	cout<<"Mul:"<<obj.mul()<<endl;
	cout<<"Sub:"<<obj.sub()<<endl;
}
