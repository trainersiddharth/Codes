
#include<iostream>

using  namespace std;

/* cal by value concept*/


int main()
{
	int a =34 , b=a;
	
	cout<<"A is "<<a<<endl;
	cout<<"B is "<<b<<endl;
	cout<<"____________"<<endl;
	
	a=44;
	
	cout<<"A is "<<a<<endl;
	cout<<"B is "<<b<<endl;
	cout<<"____________"<<endl;
	
	b=11;
	
	cout<<"A is "<<a<<endl;
	cout<<"B is "<<b<<endl;
	cout<<"____________"<<endl;	
	
	cout<<"Proof:"<<endl;
	cout<<"A:"<<&a<<endl;
	cout<<"B:"<<&b<<endl;
}
