
#include<iostream>

using namespace std;

int main()
{
	/* pointer to pointer */
	
	int num =34;
	int *ptr= &num;
	
	/*  pointer to pointer (Double Pointer )*/
	
	int **p= &ptr;
	
	cout<<num<<endl;
	cout<<*ptr<<endl;
	cout<<**p<<endl;
	cout<<"____________________________"<<endl;
	
	num=4;
	
	cout<<num<<endl;
	cout<<*ptr<<endl;
	cout<<**p<<endl;
	cout<<"____________________________"<<endl;
	
	*ptr=6;
	
	cout<<num<<endl;
	cout<<*ptr<<endl;
	cout<<**p<<endl;
	cout<<"____________________________"<<endl;	
	
	**p=77;
	
	cout<<num<<endl;
	cout<<*ptr<<endl;
	cout<<**p<<endl;
	cout<<"____________________________"<<endl;		
	
}


