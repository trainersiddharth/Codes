#include<iostream>

/*

Pointers are reference type variables in C or in C++
*/

using namespace std;

int main()
{
	 int num =34;	
	 int *ptr = &num ;
	 
	 cout<<"N: "<<num<<endl;
	 cout<<"P: "<<*ptr<<endl;
	 cout<<"_______________________"<<endl;
	 
	 num=45;
	 
	 cout<<"N: "<<num<<endl;
	 cout<<"P: "<<*ptr<<endl;
	 cout<<"_______________________"<<endl;
	 
	 *ptr=67;
	 
	 cout<<"N: "<<num<<endl;
	 cout<<"P: "<<*ptr<<endl;
	 cout<<"_______________________"<<endl;
	 
	 cout<<"\nProof:\n"<<endl;
	 cout<<"N: "<<&num<<endl;
	 cout<<"P: "<<ptr<<endl;	 
}
