#include<iostream>

using namespace std;

int main()
{
	char name[20]="James David";
	char *ptr=name;
	
	/*show complete name*/	
	cout<<ptr<<endl;
	/* show starting character */
	cout<<*ptr<<endl;
	
	/* show starting character */
	cout<<*(ptr+4)<<endl;	
}
