#include<iostream>
/* creating macros in c++ */
#define num 34
#define name "James"

using namespace std;

int main()
{
	cout<<name<<endl;
	cout<<num<<endl;
}
