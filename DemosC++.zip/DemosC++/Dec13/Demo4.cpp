
#include<iostream>

using namespace std;

int main()
{
	int arr[4] = {23,34,11,21};
	
	int *ptr= arr;
	
	for(int i=0;i<4;i++)
	{
		cout<<*(ptr+i)<<endl;
	}
}
