#include<iostream>

using namespace std;

int main(){
	
/* 
	Check weather the number is prime or not
	 (1 and itself)
*/
 	int num,x=11;
 	
	//53149824
	
 	//user
 	cout<<"Enter the number"<<endl;
 	cin>>num;


	//check by divide
	for(int i=2;i<num;i++){
		
		if(num%i==0){
			x=1;
		}
	}
	
	
	//send answer
	if(x==11){
		cout<<"The Number is Prime"<<endl;
	}else{
		cout<<"The Number is Not Prime"<<endl;
	}

}

