#include<iostream>

using namespace std;


	/* 
		3 steps
	
		declare 
		user data
		condition check numbers repetation
		result
	*/

int main(){
	
	/*1 declare */
	
	int a[10] , count=1;
	
	/* 2 user data*/
	
	for(int i=0;i<10;i++){
		cout<<"Enter the Number"<<endl;
		cin>>a[i];
	}
	
	/* 3 check and display*/
	
	for(int i=0;i<10;i++){
		
		count=1;
		for(int j=i+1;j<10;j++){
			
			if(a[i]==a[j]){
				count++;
				a[j]=-1;
			}
		}
		
		(a[i]!=-1)?cout<<a[i]<<"="<<count<<"\n":cout<<"";
	}
}
