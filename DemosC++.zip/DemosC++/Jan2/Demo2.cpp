#include<iostream>

using namespace std;

/* 

 overloading (2 types)	
 
 1) function / method overloading
 
 2) operator overloading

 1) function overloading : name of the functions are same but signature is different

*/

class Sample{
	
	public:
	
	void go(){
		
		cout<<"Go Function"<<endl;
	} 
	
	void go(int a, int b){
		
		cout<<"A:"<<a<<endl;
		cout<<"B:"<<b<<endl;
	}
	
	void go(char c){
		
		cout<<"Character:"<<c<<endl;
	}
};

int main(){
	
	Sample s;
	
	s.go();
	s.go(34,56);
	s.go('X');
}
