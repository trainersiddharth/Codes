#include<iostream>
using namespace std;

/* 
  method / function overriding 
  
  overriding: redefine the body of parent class function in child class
*/

class Data{
	
	public:
	
	void display(){
		
		cout<<"The Display function of parent class"<<endl;
	}
};

class Child:public Data{
	
	/*override the function of parent class */
	
	
	public:
	
	void display(){
		cout<<"The Display function of cHild class is updated"<<endl;
	}	
};

int main()
{
	Child c;
	c.display();
}


/*
	rules of function overriding
	
	name and signature of the function must be same as of parent class
	
	signature include 3 things 
		
		q) no. of parameter
		b) sequence of parameter
		c) type of parameter
	
*/
