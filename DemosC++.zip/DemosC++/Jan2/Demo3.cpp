#include<iostream>

using namespace std;
/*
	constructor overloading
	
	multiple constructor in the same class with different signature is allowed 
*/

class Data{
	
	public:
		
	Data(){
		cout<<"The Constructor "<<endl;
	}
	
	Data(int a){
		cout<<"The value is  "<<a<<endl;
	}
	
	Data(char c){
		cout<<"Character is "<<c<<endl;
	}
};


int main()
{
	/* calling different constructor at same time */
	Data x;
	Data x1('X');
	Data x2(34);
}
