#include<iostream>

using namespace std;

/*Here we can show ambiguity problem*/


class A{
	
	public:
		
	void display(){
		cout<<"A display()"<<endl;
	}	
};

class B{
	
	public:

	void display(){
		cout<<"B display()"<<endl;
	}		
};

class C:public A , public B {
	
};

int main(){
	C obj;

	obj.A::display();
	obj.B::display();
}

// [Error] request for member 'display' is ambiguous
