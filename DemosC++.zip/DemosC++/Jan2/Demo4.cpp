#include<iostream>

using namespace std;

/*multiple inheritance in C++ 
	
	when we have two parent and one child
	
*/

class A{
	
	public:
		
	void display(){
		cout<<"The Display function"<<endl;
	}	
};

class B{
	
	public:
	
	void go(){
		cout<<"The Go Function is here"<<endl;
	}	
};


/* here we can show the multiple inheritance*/

class C:public A , public B {
	
};

int main(){
	
	C obj;
	obj.display();
	obj.go();
}
