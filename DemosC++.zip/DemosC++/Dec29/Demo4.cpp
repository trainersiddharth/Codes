
#include<iostream>

using namespace std;

/* multi level parent -> child class -> child's  child  class*/


class Data{
	
	public:
	
	void go(){
		cout<<"The Go Function of  the parent class"<<endl;
	}	
};

class CData:public Data{
	
};

class MyChild :public CData{
	
};

 int main(){
 	
 	MyChild ovj;
 	ovj.go();
 	
 }
