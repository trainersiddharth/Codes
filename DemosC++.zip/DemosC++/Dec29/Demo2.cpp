#include<iostream>
using namespace std;

/*
	Parent class , super class  ,  Base class 
*/


class Employee{
	
	public:
	
	/* constructor of the class*/
	
	Employee(){
		cout<<"The Constructor of Parent"<<endl;
	}	
	
	/* desctructor of the class*/
	~Employee(){
		cout<<"the Desctructor Symbol"	<<endl;
	}
	
};

/* child class , sub class , derived class */

class Manager:public Employee{
	
	public:
	/* constructor of the class*/	
	Manager(){
		cout<<"THe Constructor of Manager class"<<endl;
	}	
	/* desctructor of the class*/
	
	~Manager(){
		cout<<"The Manager Desctructor"<<endl;
	}
	
};

int main(){
	
	
	/* object of the child class manager*/
	Manager obj;
}

