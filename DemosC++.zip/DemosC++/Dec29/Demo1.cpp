#include<iostream>

using namespace std;

/*Parent class*/

class Data{
	
	public:
		
	void display(){
		cout<<"The Display function of the class"<<endl;
	}
	
};

/* scope resplution (::)   (inheritance) (:)*/



/*this is the child class of (Data) */
class Sample:public Data{
	
};


int main(){
	
	Sample obj;
	/* function of parent class is called by the object of child*/
	obj.display();
	
	Data o;
	o.display();
}


/* what is inheritance> 
	
	When one class uses the properties of another class is known as inheritance
	
	Sample is using the function(display()) of its parent class (Data)

*/
